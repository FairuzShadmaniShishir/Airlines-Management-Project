
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class DatabaseTesting {
    
    private Connection connect = null; 
    private PreparedStatement preparedStatement = null;
    
    public void setConnection(){
        // Connecting...
        //Connect...
        //PreparedStatement...
    }
    public ResultSet executeQuery(String query){
        ResultSet resultSet=null;
        // Execute the query...
        return resultSet;
    }
    
    public void showResultData(ResultSet resultSet){
        //Show all the records...
    }
}
