
import java.sql.ResultSet;





public class Main {
    public static void main(String[] args) throws Exception {
        MySQLAccess ob1=new  MySQLAccess ();
        ob1.setConnection();
        //ob1.runMyQuery();
      // DatabaseTesting ob = new DatabaseTesting();
       //ob.setConnection();
       //String query = "";
       //ResultSet rs = ob.executeQuery(query);
       //ob.showResultData(rs);
        
        Select_dbFrame ob=new Select_dbFrame();
        ob.setVisible(true);
    }

}
